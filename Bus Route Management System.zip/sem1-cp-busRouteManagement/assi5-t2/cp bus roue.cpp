//# include <iostream>
//#include <string>
//using namespace std;
//void main()
//{
//	int n, CNIC, age, routeno, confirmation ;
//	string Name;
//	int cnic[100];
//	string name[100];
//	int customer = 0;
//	int task = 0;
//	while (task< 4)
//	{
//		cout << "Press 1 to book ticket " << endl;
//		cout << "Press 2 to search any name " << endl;
//		cout << "Press 3 to delete any name " << endl;
//		cin >> task  ;
//		while (task == 1)
//		{
//			cout << "Do you want to book your tickets ? " << endl;
//			cout << "If yes press 1" << endl;
//			cout << "If no press 2" << endl;
//			cin >> n;
//			if (n == 2)
//			{
//				cout << "ticket not booked" << endl;
//			}
//			if (n == 1)
//			{
//				cout << "Proceeding to next step " << endl;
//				cout << "Enter your name: " << endl;
//				cin.ignore();
//				getline(cin, Name);
//				cout << "Enter your nic number : " << endl;
//				cin >> CNIC;
//				cout << "Enter your Age : " << endl;
//				cin >> age;
//				//store name and cnic
//				name[customer] = Name;
//				cnic[customer] = CNIC;
//				customer++;
//				{
//					if (age < 18)
//					{
//						cout << "You are under age and not allowed to book your tickets, Thank you!" << endl;
//					}
//					else if (age >= 18)
//					{
//						cout << "Kindly choose one route " << endl;
//						cout << "Press 1 to choose Route 1 " << endl;
//						cout << "Press 2 to choose Route 2 " << endl;
//						cout << "Press 3 to choose Route 3 " << endl;
//						cin >> routeno;
//						{
//							if (routeno == 1)
//								cout << "Chargers are Rs.1000" << endl;
//							else if (routeno == 2)
//								cout << "Chargers are Rs.2000" << endl;
//							else if (routeno == 3)
//								cout << "Chargers are Rs.3000" << endl;
//							cout << "Do you want to continue to generate the ticket?  " << endl;
//							{
//								cout << "If confirm press 1 " << endl;
//								cout << "If not confirm press 2 " << endl;
//								cin >> confirmation;
//
//								if (confirmation == 1)
//								{
//									cout << "Generate ticket " << endl;
//									cout << "Name: " << Name << endl;
//									cout << "CNIC: " << CNIC << endl;
//									cout << "Age: " << age << endl;
//									cout << "Route: " << routeno << endl;
//									cout << "Thank You! " << endl;
//
//								}
//								else if (confirmation == 2)
//									cout << "Thank you!" << endl;
//
//							}
//						}
//					}
//				}
//			}
//			cout << "Press 1 to book ticket " << endl;
//			cout << "Press 2 to search any name " << endl;
//			cout << "Press 3 to delete any name " << endl;
//			cin >> task;
//		}
//		
//		while (task  == 2)
//		{
//			string searchval;
//			cout << "Enter the name of the customer you want to search for: " << endl;
//			cin >> searchval;
//			for (int i = 0; i < customer; i++)
//			{
//				if (name[i] == searchval)
//				{
//					cout << "Name : " << name[i] << endl;
//					cout << "cnic : " << cnic[i] << endl;
//					break;
//				}
//			}
//			cout << "Press 1 to book ticket " << endl;
//			cout << "Press 2 to search any name " << endl;
//			cout << "Press 3 to delete any name " << endl;
//			cin >> task;
//		}
//		
//		while (task == 3)
//		{
//			string deleteval;
//			cout << "Enter the name of the customer you want to delete : " << endl;
//			cin >> deleteval;
//			for (int i = 0; i < customer; i++) {
//				if (name[i] == deleteval)
//				{
//					name[i] = deleteval;
//					for (int j = i; j < customer; j++)
//						name[j] = name[j + 1];
//					break;
//				}
//			}
//			cout << "Press 1 to book ticket " << endl;
//			cout << "Press 2 to search any name " << endl;
//			cout << "Press 3 to delete any name " << endl;
//			cin >> task;
//		}	
//	}
//	system("pause");
//}
// search
// update
// delete
// store
// display
// read and write
// lib sys in which name,id of book and all the other stuff
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int book = 0;
int i = 0;
struct info {
	string name;
	int id;
}give[100];
void search() {
	int searc;
	cout << "Input id to search=";
	cin >> searc;
	for (i = 0; i < book; i++) {
		if (give[i].id == searc) {

			cout << "Name = " << give[i].name << endl << "ID = " << give[i].id;
		}
		else {
			cout << "id not found" << endl;
		}
	}
}
void update() {
	int old, newo;
	cout << "Input id to update =";
	cin >> old;
	cout << "Input id to update to =";
	cin >> newo;
	for (i = 0; i < book; i++) {
		if (give[i].id == old) {
			give[i].id = newo;
			cout << "ID = " << newo << endl << "Name = " << give[i].name;
		}
	}
}
void delet() {
	int del;
	cout << "Input id to delete =";
	cin >> del;
	for (i = 0; i < book; i++) {
		if (give[i].id == del) {
			del = give[i].id;
			for (int j = i; j < book; j++) {
				give[j].id = give[j + 1].id;
				break;
			}
		}
	}
}
void store() {
	cout << "Name = ";
	cin.ignore();
	getline(cin, give[book].name);
	cout << "ID = ";
	cin >> give[book].id;
	book++;
}
void display() {
	for (i = 0; i < book; i++) {
		cout << "Name = " << give[i].name << endl << "ID = " << give[i].id;
	}
}
void write() {
	ofstream in;
	in.open("final:(.txt", ios::app);
	for (i = 0; i < book; i++) {
		in << "Name = " << give[i].name << endl << "ID = " << give[i].id;
	}
	in.close();
}
void read() {
	ifstream out;
	string line;
	out.open("final:(.txt", ios::app);
	while (out.eof() == 0) {
		getline(out, line);
		cout << line << endl;
	}
	out.close();
}
int main() {
	int option, choic;
	do {
		cout << "----------welcome--------------" << endl;
		cout << "1. search  2. update  3. delete   4. store   5. display   6. read   " << endl;
		cin >> option;
		if (option == 1) {
			search();
		}
		if (option == 2) {
			update();
		}
		if (option == 3) {
			delet();
		}
		if (option == 4) {
			store();
		}
		if (option == 5) {
			display();
		}
		if (option == 6) {
			write();
			read();
		}
		cout << endl << "Again ? 1 ?";
		cin >> choic;
	} while (choic == 1);
}




