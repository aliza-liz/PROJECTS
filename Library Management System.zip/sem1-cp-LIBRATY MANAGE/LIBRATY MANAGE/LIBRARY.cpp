#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int i = 0;
int k = 0;
int j = 0;
int q = 0;
struct stdata
{
	int Studentid;
	string Name;
	int Age;
	string Booktitle;
	int Book_ISBN;
	int Duration;

}custside[100];
struct bookrec
{
	int Book_ID;
	string Book_Title;
	string Author_Name;

}staffside[100];
void student()
{
	int customer, age, op1;
	cout << "-------------------------------------------" << endl << "Welcome to Customer side." << endl << "-------------------------------------------"
		<< endl << "1. Borrow books " << endl<<"2. Display all book details" << endl;
	cin >> customer;
	if (customer == 1)
	{
		cout << endl << "| BOOK MUST BE ISSUED TO YOU FOR ONLY ONE MONTH |" << endl << endl << "Now enter your age for further processing." << endl << "Age = ";
		cin >> age;
		cout << "-------------------------------------------" << endl;

		if (age >= 16)
		{
			do {
				cout << "You are ELIGIBLE to issue any book." << endl << "NOW ENTER THE FOLLOWING DATA." << endl;
				cout << "-------------------------------------------" << endl;
				cout << "Student ID = ";
				cin >> custside[i].Studentid;
				cout << "Your Name = ";
				cin.ignore();
				getline(cin, custside[i].Name);
				cout << "Age = ";
				cin >> custside[i].Age;
				cout << "Book Title = ";
				cin.ignore();
				getline(cin, custside[i].Booktitle);
				cout << "Book ISBN = ";
				cin >> custside[i].Book_ISBN;
				cout << "Duration of issue can only be for 1 month. Enter 1 in month duration " << endl << "Month Duration = ";
				cin >> custside[i].Duration;
				cout << endl << "-------------------------------------------" << endl;
				i++;
				cout << "Write 1 if you want to borrow any other book." << endl;
				cin >> op1;
			} while (op1 == 1);
			cout << "-------------DETAILS INSERTED--------------" << endl;
			for (k = 0; k < i; k++)
			{
				cout << "Student ID = " << custside[k].Studentid << endl;
				cout << "Name = " << custside[k].Name << endl;
				cout << "Age = " << custside[k].Age << endl;
				cout << "Book Title = " << custside[k].Booktitle << endl;
				cout << "Book ISBN = " << custside[k].Book_ISBN << endl << endl;
				cout<< "-------------------------------------------" << endl;
			}
		}
		else
		{
			cout << "You are not eligible to issue any book." << endl;
		}
	}
	if (customer == 2)
	{
		cout << endl << "----- ALL BOOKS DETAILS INSERTED -----" << endl;
		string scontent;
		ifstream srfile;
		srfile.open("Staff Books details.txt", ios::app);
		while (srfile.eof() == 0)
		{
			getline(srfile, scontent);
			cout << scontent << endl;
		}
		srfile.close();
	}
	cout << endl;
}
void writeborrow()
{
	//writing all data of student borrow book in a file
		ofstream bwfile;
		bwfile.open("Borrow details.txt" , ios::app);
		for (k = 0; k < i; k++)
		{
			bwfile << "Student ID = " << custside[k].Studentid << endl
				<< "Name = " << custside[k].Name << endl
				<< "Age = " << custside[k].Age << endl
				<< "Book Title = " << custside[k].Booktitle << endl
				<< "Book ISBN = " << custside[k].Book_ISBN << endl << endl;
		}
		bwfile.close();
}
void readborrow()
{
	//now reading all data of student borrow book in a file
	cout << "----------DETAILS OF STUDENTS WRITTEN IN FILE----------" << endl;
	string bcontent;
	ifstream brfile;
	brfile.open("Borrow details.txt", ios::app);
	while (brfile.eof() == 0)
	{
		getline(brfile, bcontent);
		cout << bcontent << endl;
	}
	brfile.close();
}
void staff()
{
	int login, pass, op;
	cout << "-------------------------------------------" << endl << "Welcome to Employee side." << endl << "-------------------------------------------" << endl;
	int login_id = rand() % 100 + 1;
	int password = rand() % 100 + 1;
	cout << "|WE WILL PROVIDE YOU THE ID AND PASSWORD AS YOU DON'T HAVE ONE ALREADY.|" << endl;
	cout << "This is the login id provied you = " << login_id << endl << "This is the password provied you = " << password << endl;
	cout << "Enter login id = ";
	cin >> login;
	cout << "Enter password = ";
	cin >> pass;
	if (login == login_id && pass == password)
	{
		do
		{
			cout << "-------------------------------------------" << endl;
			cout << "KEEP RECORD OF BOOKS " << endl;
			cout << endl << "Book ID = ";
			cin >> staffside[q].Book_ID;
			cout << "Book Title = ";
			cin.ignore();
			getline(cin, staffside[q].Book_Title);
			cout << "Auther Name = ";
			cin.ignore();
			getline(cin, staffside[q].Author_Name);
			cout << "-------------------------------------------" << endl;
			q++;
			cout << "Write 1 if you want to enter any other book detail. " << endl;
			cin >> op;
		} while (op == 1);
		cout << "-------------DETAILS INSERTED--------------" << endl;
		for (j = 0; j < q; j++)
		{
			cout << "Book ID = " << staffside[j].Book_ID << endl;
			cout << "Book Title = " << staffside[j].Book_Title << endl;
			cout << "Auther Name = " << staffside[j].Author_Name << endl ;
			cout << "-------------------------------------------" << endl;

		}
	}
	else
	{
		cout << "You have entered your ID or Password incorrect. Please try again." << endl;
	}
}
void writestaff()
{
	//writing all data of staff book in a file
	ofstream swfile;
		swfile.open("Staff Books details.txt", ios::app);
		for (j = 0; j < q; j++)
		{
			swfile << "Book ID = " << staffside[j].Book_ID << endl
				<< "Book Title = " << staffside[j].Book_Title << endl
				<< "Auther Name = " << staffside[j].Author_Name << endl<<endl ;
		}
		swfile.close();
}
void readstaff()
{
	//now reading all data of staff book in a file
	cout << "----------DETAILS OF BOOKS WRITTEN IN FILE----------" << endl;
	string scontent;
	ifstream srfile;
	srfile.open("Staff Books details.txt", ios::app);
	while (srfile.eof() == 0)
	{
		getline(srfile, scontent);
		cout << scontent << endl;
	}
	srfile.close();
}
void sea()
{
	if (j > 0)
	{
		int search;
		cout << "Enter Book ID you want to Search = ";
		cin >> search;
		cout << endl;
		for (j = 0; j < q; j++)
		{
			if (search == staffside[j].Book_ID)
			{
				staffside[j].Book_ID = search;
				cout << "SEARCHED BOOK DETAILS ARE HERE " << endl << "Book ID = " << staffside[j].Book_ID << endl
					<< "Book Title = " << staffside[j].Book_Title << endl
					<< "Auther Name = " << staffside[j].Author_Name << endl;
				cout << "-------------------------------------------" << endl;
			}
			else
			{
				cout << "Not found";
			}
		}
	}
	else
	{
		cout << "No books details inserted till now" << endl;
	}
}

int main()
{
	int side, task;
	do
	{
		cout << "---------------------- WELCOME TO MAIN MENU -----------------------" << endl
			<<"CHOOSE FROM THE FOLLOWING OPTIONS THEN WE WILL MORE TO FURTHER SECTIONS" << endl
			<< endl << "1. Customer side" << endl << "2. Employee side" << endl << "3. Search Book" << endl;
		cin >> side;
		if (side == 1)
		{
			 student();
			 writeborrow();
			 readborrow();
		}
		if (side == 2)
		{
			 staff();
			 writestaff();
			 readstaff();
		}
		if (side == 3)
		{
			sea();
		}
		cout << "Would you like to perform any other task? (1=yes , 2=no) ";
		cin >> task;
	} while (task == 1);
}